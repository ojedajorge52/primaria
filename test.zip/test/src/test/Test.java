package test;

/**
 *
 * @author Jorge
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BD Obj=new BD();
        Obj.setVisible(true);
    }
    
}
